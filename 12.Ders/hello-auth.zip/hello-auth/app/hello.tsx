// rnfe

import { useAuth } from '@/src/contexts/AuthContext';
import React from 'react';
import { Text, View } from 'react-native';

const Hello = () => {
    const { auth } = useAuth();

    return (
        <View>
            <Text>{auth.session?.user.email}</Text>
        </View>
    )
}

export default Hello